#pragma once

int search_closest(double *vec, double val);
